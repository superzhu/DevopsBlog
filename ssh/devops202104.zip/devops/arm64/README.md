# kubernetes deployment on arm64 platform

<p>Purpose: create ansible scripts for deploying kubernetes on arm64(v8) platform based on cloud environments</p>

## Main Deploying Steps(Run as root user):
1. Setup SSH Passwordless Login
  ```bash
      # Run as root user
      ansible-playbook -i inventory/hosts passwordless.yaml
  ```
2. Harden OS
  ```bash
     ansible-playbook 01.prepare.yaml
  ```
3. Install docker
  ```bash
    ansible-playbook setup.yaml -t docker
  ```
4. Generate certificates used in kubernetes cluster
  ```bash
    ansible-playbook setup.yaml -t tls
  ```
5. Install etcd3 service
  ```bash
    ansible-playbook setup.yaml -t etcd
  ```
6. Distribute self-generated certificates to master/worker nodes
  ```bash
    ansible-playbook setup.yaml -t disTLS
  ```
7. Deploy master componets
  ```bash
    ansible-playbook setup.yaml -t master
  ```
8. Generate kubelet TLS bootstrapping kubeconfig
  ```bash
    ansible-playbook setup.yaml -t bootstrap
  ```
9. Deploy node components
  ```bash
    ansible-playbook setup.yaml -t node
  ```
10. Deploy kubernetes network plugin calico
  ```bash
    ansible-playbook setup.yaml -t calico
  ```

11. Install addons using helm
  ```bash
   helm upgrade metrics-server ./metrics-server --debug --install --namespace=kube-system --set image.repository=mirrorgcrio/metrics-server-arm64
   helm upgrade coredns ./coredns --debug --install --namespace=kube-system
   helm upgrade nginx-ingress ./nginx-ingress --debug --install --namespace=kube-system
   helm upgrade rabbitmq ./rabbitmq-ha --debug --install --namespace kube-system
  ```
12. ff
