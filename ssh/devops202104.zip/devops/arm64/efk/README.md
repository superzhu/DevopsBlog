# Deployment EFK on arm64

1. elasticsearch deployment
    ```bash
    helm upgrade elasticsearch1 ./elasticsearch --debug --install -n logging -f ./elasticsearch/values.yaml
    ```
2. fluentd deployment
    ```bash
    helm upgrade fluentd ./fluentd-elasticsearch --debug --install -n logging -f ./fluentd-elasticsearch/values-h.yaml
    ```
3. kibana deployment
   ```bash
   helm upgrade kibana ./kibana --debug --install -n logging -f ./kibana/values.yaml
   ```
4. ff