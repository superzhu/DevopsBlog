#!/bin/bash

# Install python3 and python3-pip
yum localinstall -y -v $(pwd)/bashscripts/python3/*.rpm

mkdir -p ~/.ssh
chmod 0700 ~/.ssh

cp $(pwd)/bashscripts/python3/config ~/.ssh
cat $(pwd)/bashscripts/python3/union_rsa.pub >> ~/.ssh/authorized_keys
cp $(pwd)/bashscripts/python3/union_rsa  ~/.ssh
chmod 0600 ~/.ssh/authorized_keys
chmod 0600 ~/.ssh/union_rsa
