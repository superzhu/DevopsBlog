#!/bin/bash

# Install ansible
yum localinstall -y -v $(pwd)/bashscripts/ansible/*.rpm

pip3 install --user $(pwd)/bashscripts/pip3/zipp-3.4.0-py3-none-any.whl
pip3 install --user $(pwd)/bashscripts/pip3/importlib_resources-3.3.0-py2.py3-none-any.whl

pip3 install --user $(pwd)/bashscripts/pip3/netaddr-0.8.0-py2.py3-none-any.whl

pip3 install --user $(pwd)/bashscripts/pip3/ipaddr-2.2.0.tar.gz

pip3 install --user $(pwd)/bashscripts/pip3/pymongo-3.11.1-cp36-cp36m-manylinux1_x86_64.whl
pip3 install --user $(pwd)/bashscripts/pip3/dnf-0.0.1-py2.py3-none-any.whl

echo "export PATH=$PATH:$HOME/.local/bin" >> ~/.bash_profile
