#!/bin/bash
sourcepath='/usr/bin'
targetpath='/mongodb_bak/backup'
nowtime=$(date "+%Y%m%d")
start()
{
        ${sourcepath}/mongodump --port 30003 -u admin -p "super_admin_123" --oplog --gzip --authenticationDatabase "admin" --out ${targetpath}/${nowtime}
}
execute()
{

        echo "================================ $(date) mongodb back start  ${nowtime}========="

        start
        if [ $? -eq 0 ]
        then
                echo "The MongoDB BackUp Successfully!"
        else "The MongoDB BackUp Failure"
        fi
}
if [ ! -d "${targetpath}/${nowtime}/" ]
then
          mkdir ${targetpath}/${nowtime}
  fi
  execute

  baktime=$(date -d '-10 days' "+%Y%m%d")
  if [ -d "${targetpath}/${baktime}/" ]
  then
            rm -rf "${targetpath}/${baktime}/"
      fi

      echo "================================ $(date) mongodb back end ${nowtime}========="
