#!/bin/bash
command_linebin="/usr/bin/mongo"
username="admin"
password="super_admin_123"
port="30003"
####
####comments0 start 检查并创建备份路径 ####
if [ ! -d "/mongodb_bak/mongodboplog_back/mongo$port" ]
then
  mkdir -p /mongodb_bak/mongodboplog_back/mongo$port
fi

if [ ! -d "/mongodb_bak/mongodboplog_back/log/$port" ]
then
  mkdir -p /mongodb_bak/mongodboplog_back/log/$port
fi

bkdatapath=/mongodb_bak/mongodboplog_back/mongo$port
bklogpath=/mongodb_bak/mongodboplog_back/log/$port

####comments0 end ##

logfilename=$(date -d today +"%Y%m%d")

echo "===================================Message --=MongoDB 增量备份开始，开始时间为" $(date -d today +"%Y%m%d%H%M%S") >> $bklogpath/$logfilename.log

ParamBakEndDate=$(date +%s)
echo "Message --本次备份时间参数中的结束时间为：" $ParamBakEndDate >> $bklogpath/$logfilename.log

DiffTime=$(expr 65 \* 60)

echo "Message --备份设置的间隔时间为：" $DiffTime >> $bklogpath/$logfilename.log

ParamBakStartDate=$(expr $ParamBakEndDate - $DiffTime)
echo "Message --本次备份时间参数中的开始时间为：" $ParamBakStartDate >> $bklogpath/$logfilename.log

DiffTime=$(expr 61 \* 60)
ParamAfterBakRequestStartDate=$(expr $ParamBakEndDate - $DiffTime)
echo "Message --为保证备份的连续性,本次备份后,oplog中的开始时间需小于：" $ParamAfterBakRequestStartDate >> $bklogpath/$logfilename.log
##### end

bkfilename=$(date -d today +"%Y%m%d%H%M%S")

#### comments1 start 获取数据库中oplog记录的开始范围，防止导出的数据不完整 ####

command_line="${command_linebin} admin --port $port -u $username -p $password"

opmes=$(/bin/echo "db.printReplicationInfo()" | $command_line --quiet)

echo $opmes > opdoctime.tmplog

opbktmplogfile=opdoctime.tmplog

#opstartmes=$(grep "oplog first event time" $opmes)

opstartmes=$(grep "oplog first event time" $opbktmplogfile | awk -F 'CST' '{print $1}' | awk -F 'oplog first event time: '  '{print $2}' | awk -F ' GMT' '{print $1}'  )

echo "Message --oplog集合记录的开始时间为："$opstartmes >> $bklogpath/$logfilename.log

oplogRecordFirst=$(date -d "$opstartmes"  +%s)

echo "Message --oplog集合记录的开始时间为:" $oplogRecordFirst >> $bklogpath/$logfilename.log

if [ $oplogRecordFirst -le $ParamBakStartDate ]
then
        echo "Message --检查设置备份时间合理。备份参数的开始时间在oplog记录的时间范围内。" >> $bklogpath/$logfilename.log
else echo "Fatal Error --检查设置的备份时间不合理。备份参数的开始时间不在oplog记录的时间范围内。本次备份可以持续进行，但还原时数据完整性丢失。" >> $bklogpath/$logfilename.log
fi

#### comments1 end  ####

/usr/bin/mongodump --port $port -d local -c oplog.rs -u $username -p $password --authenticationDatabase admin --query '{"ts":{"$gte":{"$timestamp":{"t":'$ParamBakStartDate',"i":1}},"$lte":{"$timestamp":{"t":'$P
aramBakEndDate',"i":9999}}}}' -o $bkdatapath/mongodboplog$bkfilename >> $bklogpath/$logfilename.log 2>&1

#### comments2 start ####
opmes=$(/bin/echo "db.printReplicationInfo()" | $command_line --quiet)
echo $opmes > opdoctime.tmplog
opbktmplogfile=opdoctime.tmplog
opstartmes=$(grep "oplog first event time" $opbktmplogfile | awk -F 'CST' '{print $1}' | awk -F 'oplog first event time: '  '{print $2}' | awk -F ' GMT' '{print $1}'  )
echo "Message --执行备份后,oplog集合记录的开始时间为："$opstartmes >> $bklogpath/$logfilename.log
oplogRecordFirst=$(date -d "$opstartmes"  +%s)
echo "Message --执行备份后,oplog集合记录的开始时间为[时间格式化]:" $oplogRecordFirst >> $bklogpath/$logfilename.log

if [ $oplogRecordFirst -le $ParamAfterBakRequestStartDate ]
then
echo "Message --备份后，检查oplog集合中数据的开始时间不小于61分钟，满足文件的持续完整性，逐个还原无丢失数据风险。" >> $bklogpath/$logfilename.log
else echo "Fatal Error --备份后，检查oplog集合的涵盖的时间范围过小（小于61min）。本次备份可以持续进行，但还原时数据完整性丢失。" >> $bklogpath/$logfilename.log
fi

#### comments3 检查备份文件是否已经删除start ####
if [ -d "$bkdatapath/mongodboplog$bkfilename" ]
then
  echo "Message --备份文件已经产生.文件信息为:" $bkdatapath/mongodboplog$bkfilename >> $bklogpath/$logfilename.log
  else echo "Fatal Error --备份过程已执行，但是未检测到备份产生的文件，请检查！" >> $bklogpath/$logfilename.log
fi
##### comments3 end ####

#### comments4 start 删除历史备份文件，保留3天，如需调整，请在持续设置
keepbaktime=$(date -d '-10 days' "+%Y%m%d%H")*
if [ -d $bkdatapath/mongodboplog$keepbaktime ]
then
  rm -rf $bkdatapath/mongodboplog$keepbaktime
  echo "Message -- $bkdatapath/mongodboplog$keepbaktime 删除完毕" >> $bklogpath/$logfilename.log
fi
### comments4 end

echo "============================Message --MongoDB 增量备份结束，结束时间为：" $(date -d today +"%Y%m%d%H%M%S") >> $bklogpath/$logfilename.log

