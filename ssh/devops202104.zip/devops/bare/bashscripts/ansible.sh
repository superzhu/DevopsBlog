#!/bin/bash

# Install ansible
dpkg -i $(pwd)/bashscripts/pip3/*.deb

pip3 install $(pwd)/bashscripts/ansible/MarkupSafe-1.1.1-cp36-cp36m-manylinux1_x86_64.whl --user
pip3 install $(pwd)/bashscripts/ansible/Jinja2-2.11.2-py2.py3-none-any.whl --user

pip3 install $(pwd)/bashscripts/ansible/pycparser-2.20-py2.py3-none-any.whl --user

pip3 install $(pwd)/bashscripts/ansible/ansible-2.9.13.tar.gz --user

pip3 install $(pwd)/bashscripts/ansible/zipp-3.1.0-py3-none-any.whl --user
pip3 install $(pwd)/bashscripts/ansible/importlib_resources-3.0.0-py2.py3-none-any.whl --user

pip3 install $(pwd)/bashscripts/ansible/cffi-1.14.2-cp36-cp36m-manylinux1_x86_64.whl --user

pip3 install $(pwd)/bashscripts/ansible/cryptography-3.1-cp35-abi3-manylinux1_x86_64.whl --user

pip3 install $(pwd)/bashscripts/ansible/netaddr-0.8.0-py2.py3-none-any.whl --user

pip3 install $(pwd)/bashscripts/ansible/ipaddr-2.2.0.tar.gz --user

pip3 install $(pwd)/bashscripts/ansible/pymongo-3.11.0-cp36-cp36m-manylinux1_x86_64.whl --user

echo "export PATH=$PATH:$HOME/.local/bin" >> ~/.profile
