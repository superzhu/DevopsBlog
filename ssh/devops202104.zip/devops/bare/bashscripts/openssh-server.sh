#!/bin/bash

# Install openssh-server and vim
dpkg -i $(pwd)/bashscripts/openssh/*.deb

mkdir -p ~/.ssh
chmod 0700 ~/.ssh

cp $(pwd)/bashscripts/openssh/config ~/.ssh
cat $(pwd)/bashscripts/openssh/union_rsa.pub >> ~/.ssh/authorized_keys
cp $(pwd)/bashscripts/openssh/union_rsa  ~/.ssh
chmod 0600 ~/.ssh/authorized_keys
chmod 0600 ~/.ssh/union_rsa
