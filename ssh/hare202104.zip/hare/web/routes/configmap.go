package routes

import (
	"encoding/json"
	"fmt"
	"github.com/kataras/iris/v12"
	"hare/log"
	"hare/services"
	"k8s.io/apimachinery/pkg/api/errors"
)

func Configmap(service services.ConfigmapService, ctx iris.Context, namespace string, configmap string) (*map[string]map[string]interface{}, error) {
	cm, err := service.GetDeployProfile(namespace, configmap)
	if errors.IsNotFound(err) {
		log.Logger.Warnf("Cannot find configmap: %v in namespace: %v", configmap, namespace)
		fail(ctx, iris.StatusNotFound, "Cannot find configmap: %v in namespace: %v", configmap, namespace)
		return nil, nil
	}

	var deployTemplate map[string]map[string]interface{}
	if cm.Data != nil {
		deployTemplate = make(map[string]map[string]interface{})
		for key, value := range cm.Data {
			valueMap := make(map[string]interface{})
			err = json.Unmarshal([]byte(value), &valueMap)
			if err != nil {
				log.Logger.Warnf("Unmarshal %v, get errors: %v from configmap: %v in namespace: %v", value, err, configmap, namespace)
			} else {
				deployTemplate[key] = valueMap
			}
		}

		return &deployTemplate, err
	} else {
		log.Logger.Errorf("configmap: %v in namespace: %v does not contain any json data.", configmap, namespace)
		fail(ctx, iris.StatusNotFound, "configmap: %v in namespace: %v does not contain any json data.", configmap, namespace)
		return nil, nil
	}
}

// common JSON response for manual HTTP errors, optionally.
type httpError struct {
	Code   int    `json:"code"`
	Reason string `json:"reason"`
}

func fail(ctx iris.Context, statusCode int, format string, a ...interface{}) {
	err := httpError{
		Code:   statusCode,
		Reason: fmt.Sprintf(format, a...),
	}

	// log all the >= 500 internal errors.
	if statusCode >= 500 {
		log.Logger.Error(err)
	}

	ctx.StatusCode(statusCode)
	_, error := ctx.JSON(err)
	if error != nil {
		log.Logger.Errorf("JSON marshals have errors: %v", error)
	}

	// no next handlers will run.
	ctx.StopExecution()
}
