package routes

import (
	"github.com/kataras/iris/v12"
	"hare/log"
	"hare/services"
	"hare/web/models"
)

func GetConf(service services.LogrotateService, ctx iris.Context) (models.LogrotateVO, error) {
	log.Logger.Infof("Get logrotate configuration (route)")

	response, err := service.GetConf(ctx)
	if err != nil {
		fail(ctx, iris.StatusInternalServerError, "Logrotate service has error: %v", err.Error())
		return response, err
	}

	return response, nil
}

func UpdateConf(service services.LogrotateService, ctx iris.Context) (string, error) {
	log.Logger.Infof("Update logrotate configuration (route)")

	var newConf models.LogrotateVO
	err := ctx.ReadJSON(&newConf)
	if err != nil {
		fail(ctx, iris.StatusBadRequest, "input json format is not correct, error: %v", err.Error())
		return EmptyString, nil
	}

	response, err := service.UpdateConf(ctx, newConf)
	if err != nil {
		fail(ctx, iris.StatusInternalServerError, "Update logrotate configuration has error: %v", err.Error())
		return EmptyString, nil
	}

	return response, nil
}
