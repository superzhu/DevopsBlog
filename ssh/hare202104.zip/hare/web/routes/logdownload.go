package routes

import (
	"github.com/kataras/iris/v12"
	"hare/log"
	"hare/services"
)

func Download(service services.LogDownloadService, ctx iris.Context, namespace string) (string, error) {
	log.Logger.Infof("LogDownloadService request namespace: %s", namespace)

	//ctx.ContentType("application/gzip; charset=UTF-8")
	//ctx.ContentType("application/x-compressed-tar; charset=UTF-8")
	response, err := service.Download(ctx, namespace)
	if err != nil {
		fail(ctx, iris.StatusInternalServerError, "Log Download service has error: %v", err.Error())
		return EmptyString, nil
	}

	return response, nil
}
