package routes

import (
	"github.com/kataras/iris/v12"
	"hare/services"
	"hare/web/models"
)

// Namespaces returns list of the Kubernetes namespaces.
// curl -i http://localhost:8080/namespaces
func Namespaces(service services.NamespaceService) (results []models.NamespaceVO, err error) {
	namespaces, err := service.GetAll()
	return namespaces, err
}

func Create(service services.NamespaceService, ctx iris.Context, namespace string) (string, error) {
	response, err := service.Create(namespace)
	if err != nil {
		fail(ctx, iris.StatusInternalServerError, "Create namespace has error: %v", err.Error())
		return EmptyString, nil
	}

	return response, nil
}
