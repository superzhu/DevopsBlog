package routes

import (
	"github.com/kataras/iris/v12"
	"hare/log"
	"hare/services"
	"hare/web/models"
	v1 "k8s.io/api/apps/v1"
	"k8s.io/apimachinery/pkg/api/errors"
)

const (
	EmptyString string = ""
)

// Deployments returns list of the Kubernetes deployment in a namespace.
func List(service services.DeploymentService, namespace string) ([]models.DeploymentVO, error) {
	var deploys []models.DeploymentVO

	statefulSetList, err := service.GetStatefulSetList(namespace)
	if errors.IsNotFound(err) {
		log.Logger.Warnf("Cannot get statefulset in namespace: %v,error is %v", namespace, err)
	} else if statusError, isStatus := err.(*errors.StatusError); isStatus {
		log.Logger.Warnf("Error getting deployment%v", statusError.ErrStatus.Message)
	}

	for _, item := range statefulSetList.Items {
		deploy := models.DeploymentVO{}

		deploy.Name = item.Name
		deploy.Namespace = item.Namespace
		deploy.CreationTimestamp = item.CreationTimestamp
		deploy.LastUpdateTime = item.CreationTimestamp
		deploy.Replicas = *item.Spec.Replicas
		deploy.ReadyReplicas = item.Status.ReadyReplicas

		for _, condition := range item.Status.Conditions {
			deploy.LastUpdateTime = condition.LastTransitionTime
		}

		var images []string
		for _, container := range item.Spec.Template.Spec.Containers {
			image := container.Image

			images = append(images, image)
		}
		deploy.Images = images

		deploys = append(deploys, deploy)
	}

	deployments, err := service.GetDeployments(namespace)
	if err != nil {
		return nil, err
	}

	for _, item := range deployments.Items {
		deploy := models.DeploymentVO{}

		deploy.Name = item.Name
		deploy.Namespace = item.Namespace
		deploy.CreationTimestamp = item.CreationTimestamp
		deploy.Replicas = *item.Spec.Replicas
		deploy.ReadyReplicas = item.Status.ReadyReplicas

		for _, condition := range item.Status.Conditions {
			if condition.Type == v1.DeploymentProgressing {
				deploy.LastUpdateTime = condition.LastUpdateTime
			}
		}

		for _, condition := range item.Status.Conditions {
			if condition.Type == v1.DeploymentAvailable || condition.Type == v1.DeploymentReplicaFailure {
				deploy.LastUpdateTime = condition.LastUpdateTime
			}
		}

		var images []string
		for _, container := range item.Spec.Template.Spec.Containers {
			image := container.Image

			images = append(images, image)
		}
		deploy.Images = images

		deploys = append(deploys, deploy)
	}

	return deploys, nil
}

//deployment update based on input profile template
func Update(service services.DeploymentService, ctx iris.Context, namespace string) (string, error) {
	log.Logger.Infof("Update deployments in namespace: %v", namespace)
	newProfiles := make(map[string]map[string]interface{})

	err := ctx.ReadJSON(&newProfiles)
	if err != nil {
		fail(ctx, iris.StatusBadRequest, "input json format is not correct, error: %v", err.Error())
		return EmptyString, nil
	}

	response, err := service.Update(namespace, newProfiles)
	if err != nil {
		fail(ctx, iris.StatusInternalServerError, "deployment update service has error: %v", err.Error())
		return EmptyString, nil
	}

	return response, nil
}

//undeploy all services specified in slice: serviceNames
func UndeployServices(service services.DeploymentService, ctx iris.Context, namespace string) (string, error) {
	log.Logger.Infof("Undeploy services from namespace: %v", namespace)

	var serviceNames []string
	err := ctx.ReadJSON(&serviceNames)
	if err != nil {
		fail(ctx, iris.StatusBadRequest, "input json format is not correct, error: %v", err.Error())
		return EmptyString, nil
	}

	response, err := service.UndeployServices(namespace, serviceNames)
	if err != nil {
		fail(ctx, iris.StatusInternalServerError, "service undeployment has error: %v", err.Error())
		return EmptyString, nil
	}

	return response, nil
}
