package routes

import (
	"github.com/kataras/iris/v12"
	"hare/log"
	"hare/services"
)

func ListStaticLog(service services.StaticLogDownloadService, ctx iris.Context) (string, error) {
	log.Logger.Infof("List static log files on kubernetes nodes (route)")

	response, err := service.ListStaticLog(ctx)
	if err != nil {
		fail(ctx, iris.StatusInternalServerError, "List static log files on kubernetes nodes has error: %v", err.Error())
		return EmptyString, nil
	}

	return response, nil
}
