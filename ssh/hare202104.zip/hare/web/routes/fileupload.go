package routes

import (
	"github.com/kataras/iris/v12"
	"hare/services"
)

func FileUpload(service services.FileUploadService, ctx iris.Context) (results string, err error) {
	response, err := service.FileUpload(ctx)

	if err != nil && ctx.GetStatusCode() == iris.StatusBadRequest {
		fail(ctx, iris.StatusBadRequest, "FileUpload has error: %v", err.Error())
		return EmptyString, nil
	} else if err != nil && ctx.GetStatusCode() == iris.StatusForbidden {
		fail(ctx, iris.StatusForbidden, "FileUpload has error: %v", err.Error())
		return EmptyString, nil
	} else if err != nil {
		fail(ctx, iris.StatusInternalServerError, "FileUpload has error: %v", err.Error())
		return EmptyString, nil
	}

	return response, nil
}
