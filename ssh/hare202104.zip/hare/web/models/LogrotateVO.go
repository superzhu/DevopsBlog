package models

import "fmt"

type LogrotateVO struct {
	Rotate  int64  `json:"rotate,omitempty" protobuf:"varint,1,opt,name=rotate"`
	Maxsize string `json:"maxsize,omitempty" protobuf:"bytes,1,opt,name=maxsize,casttype=string"`
}

func (c LogrotateVO) String() string {
	return fmt.Sprintf("[%d, %s]", c.Rotate, c.Maxsize)
}

type LogFileVO struct {
	Hosts []Host `json:"hosts" protobuf:"bytes,2,rep,name=hosts"`
}

type Host struct {
	Apps []App `json:"apps" protobuf:"bytes,2,rep,name=apps"`
}

type App struct {
	Name    string `json:"name,omitempty" protobuf:"bytes,1,opt,name=name,casttype=string"`
	Modtime string `json:"modtime,omitempty" protobuf:"bytes,1,opt,name=modtime,casttype=string"`
	Size    int64  `json:"size,omitempty" protobuf:"varint,1,opt,name=size"`
}
