package models

import "k8s.io/apimachinery/pkg/apis/meta/v1"

type DeploymentVO struct {
	Name              string   `json:"name,omitempty" protobuf:"bytes,1,opt,name=name"`
	Namespace         string   `json:"namespace,omitempty" protobuf:"bytes,3,opt,name=namespace"`
	CreationTimestamp v1.Time  `json:"creationTimestamp,omitempty" protobuf:"bytes,8,opt,name=creationTimestamp"`
	LastUpdateTime    v1.Time  `json:"lastUpdateTime,omitempty" protobuf:"bytes,6,opt,name=lastUpdateTime"`
	Replicas          int32    `json:"replicas,omitempty" protobuf:"varint,1,opt,name=replicas"`
	Images            []string `json:"images,omitempty" protobuf:"bytes,2,opt,name=images"`
	ReadyReplicas     int32    `json:"readyReplicas,omitempty" protobuf:"varint,7,opt,name=readyReplicas"`
}
