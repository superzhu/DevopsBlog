package models

import "k8s.io/apimachinery/pkg/apis/meta/v1"

type NamespaceVO struct {
	Name              string  `json:"name,omitempty" protobuf:"bytes,1,opt,name=name"`
	CreationTimestamp v1.Time `json:"creationTimestamp,omitempty" protobuf:"bytes,8,opt,name=creationTimestamp"`
	Status            string  `json:"status,omitempty" protobuf:"bytes,1,opt,name=status,casttype=string"`
}
