package configs

import (
	"fmt"
	"github.com/pkg/errors"
	"github.com/spf13/viper"
	"os"
	"path/filepath"
)

func DirExists(path string) bool {
	fi, err := os.Stat(path)
	if err != nil {
		return false
	}
	return fi.IsDir()
}

func AddConfigPath(v *viper.Viper, p string) {
	if v != nil {
		v.AddConfigPath(p)
	} else {
		viper.AddConfigPath(p)
	}
}

//----------------------------------------------------------------------------------
// TranslatePath()
//----------------------------------------------------------------------------------
// Translates a relative path into a fully qualified path relative to the config
// file that specified it.  Absolute paths are passed unscathed.
//----------------------------------------------------------------------------------
func TranslatePath(base, p string) string {
	if filepath.IsAbs(p) {
		return p
	}

	return filepath.Join(base, p)
}

//----------------------------------------------------------------------------------
// TranslatePathInPlace()
//----------------------------------------------------------------------------------
// Translates a relative path into a fully qualified path in-place (updating the
// pointer) relative to the config file that specified it.  Absolute paths are
// passed unscathed.
//----------------------------------------------------------------------------------
func TranslatePathInPlace(base string, p *string) {
	*p = TranslatePath(base, *p)
}

//----------------------------------------------------------------------------------
// GetPath()
//----------------------------------------------------------------------------------
// GetPath allows configuration strings that specify a (config-file) relative path
//
// For example: Assume our config is located in /etc/hyperledger/fabric/core.yaml with
// a key "msp.configPath" = "msp/config.yaml".
//
// This function will return:
//      GetPath("msp.configPath") -> /etc/hyperledger/fabric/msp/config.yaml
//
//----------------------------------------------------------------------------------
func GetPath(key string) string {
	p := viper.GetString(key)
	if p == "" {
		return ""
	}

	return TranslatePath(filepath.Dir(viper.ConfigFileUsed()), p)
}

const OfficialPath = "/etc/hare"

//----------------------------------------------------------------------------------
// InitViper()
//----------------------------------------------------------------------------------
// Performs basic initialization of our viper-based configuration layer.
// Primary thrust is to establish the paths that should be consulted to find
// the configuration we need.  If v == nil, we will initialize the global
// Viper instance
//----------------------------------------------------------------------------------
func InitViper(v *viper.Viper, configName string) error {
	var altPath = os.Getenv("HARE_CFG_PATH")
	// Does not include file extension.
	var defaultConfig string = "hare"
	if altPath != "" {
		// If the user has overridden the path with an envvar, its the only path
		// we will consider

		if !DirExists(altPath) {
			return fmt.Errorf("FABRIC_CFG_PATH %s does not exist", altPath)
		}

		AddConfigPath(v, altPath)
	} else {
		// If we get here, we should use the default paths in priority order:
		// CWD
		AddConfigPath(v, "./")

		// And finally, the official path
		if DirExists(OfficialPath) {
			AddConfigPath(v, OfficialPath)
		}
	}

	// Now set the configuration file.
	if v != nil {
		if configName != "" {
			// 如果指定了配置文件，则解析指定的配置文件
			v.SetConfigFile(configName)
		} else {
			v.SetConfigName(defaultConfig)
		}
		v.SetConfigType("yaml")
	} else {
		if configName != "" {
			// 如果指定了配置文件，则解析指定的配置文件
			viper.SetConfigFile(configName)
		} else {
			viper.SetConfigName(defaultConfig)
		}
		viper.SetConfigType("yaml") // 设置配置文件格式为YAML
	}

	return nil
}

// InitConfig initializes viper config
func InitConfig(cmdRoot string, v *viper.Viper) error {
	err := InitViper(v, cmdRoot)
	if err != nil {
		return errors.Wrap(err, "")
	}

	err = v.ReadInConfig() // Find and read the config file
	if err != nil {        // Handle errors reading the config file
		return errors.Wrap(err, fmt.Sprintf("error when reading %s config file", cmdRoot))
	}

	err2 := v.Unmarshal(&Configuration)
	if err2 != nil {
		return errors.Wrap(err2, fmt.Sprintf("error when unmarshal %s config file", cmdRoot))
	}

	return nil
}
