package configs

// AppConfig represents the application config
type AppConfig struct {
	Log        Log        `yaml:"log"`
	Deployment Deployment `yaml:"deployment"`
	Server     Server     `yaml:"server"`
	Namespaces Namespaces `yaml:"namespaces"`
	Helm       Helm       `yaml:"helm"`
	Docker     Docker     `yaml:"docker"`
}

//Configuration stores the application-wide configurations
var Configuration AppConfig

// LogConfig represents logger handler
// Logger has many parameters can be set or changed. Currently, only three are listed here. Can add more into it to
// fits your needs.
type Log struct {
	// timestamp format
	TimestampFormat string `yaml:"timestampFormat"`
	// log level
	Level string `yaml:"level"`
}

// deployment status
type Deployment struct {
	Type           string `yaml:"type"`
	DestHostLogDir string `yaml:"destHostLogDir"`
}

type Server struct {
	//REST server port
	Port       int    `yaml:"port"`
	SshPort    int    `yaml:"sshPort"`
	SshUser    string `yaml:"sshUser"`
	PrivateKey string `yaml:"privateKey"`
	//service route prefix
	RoutePrefix string `yaml:"routePrefix"`
	Appid       string `yaml:"appid"`
	//maxRequestBodySize for file upload only,unit:MB
	MaxRequestBodySize    int64  `yaml:"maxRequestBodySize"`
	CustomerIngressSecret string `yaml:"customerIngressSecret"`
}

type Namespaces struct {
	Excluded []string `yaml:"excluded"`
}

type Helm struct {
	ProjectName  string `yaml:"projectName"`
	CloneCommand string `yaml:"cloneCommand"`
	PullCommand  string `yaml:"pullCommand"`
}

type Docker struct {
	Secret string `yaml:"secret"`
	Name   string `yaml:"name"`
}
