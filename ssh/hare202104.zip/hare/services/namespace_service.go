package services

import (
	"hare/configs"
	"hare/internal/kubernetes"
	"hare/log"
	"hare/web/models"
	v1 "k8s.io/api/core/v1"
	"k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
)

//Handle kubernetes namespace operations
type NamespaceService interface {
	GetAll() ([]models.NamespaceVO, error)
	Create(namespace string) (string, error)
}

// NewNamespaceService returns the default namespace service.
func NewNamespaceService() NamespaceService {
	return &namespaceService{}
}

type namespaceService struct {
}

//GetAll returns all namespaces.
func (s *namespaceService) GetAll() ([]models.NamespaceVO, error) {
	kubernetesAPI, err := kubernetes.GetKubernetesAPI()
	if err != nil {
		return nil, err
	}

	namespaces, err := kubernetesAPI.ClientSet.CoreV1().Namespaces().List(metav1.ListOptions{})
	if err != nil {
		return nil, err
	}

	var nsVOs []models.NamespaceVO
	for _, namespace := range namespaces.Items {
		_, found := find(configs.Configuration.Namespaces.Excluded, namespace.GetName())
		if found {
			continue
		}
		nsVO := models.NamespaceVO{}
		nsVO.Name = namespace.GetName()
		nsVO.CreationTimestamp = namespace.GetCreationTimestamp()
		nsVO.Status = string(namespace.Status.Phase)

		nsVOs = append(nsVOs, nsVO)
	}

	return nsVOs, nil
}

func (s *namespaceService) Create(namespace string) (string, error) {
	var response string
	kubernetesAPI, err := kubernetes.GetKubernetesAPI()
	if err != nil {
		return EmptyString, err
	}

	_, err = kubernetesAPI.ClientSet.CoreV1().Namespaces().Get(namespace, metav1.GetOptions{})
	if errors.IsNotFound(err) {
		log.Logger.Infof("namespace: %v does not exist, creating it ", namespace)
		response = "namespace: " + namespace + " does not exist, creating it"
		ns := &v1.Namespace{
			ObjectMeta: metav1.ObjectMeta{
				Name: namespace,
			},
			Status: v1.NamespaceStatus{
				Phase: v1.NamespaceActive,
			},
		}
		_, err = kubernetesAPI.ClientSet.CoreV1().Namespaces().Create(ns)
		if err != nil {
			return EmptyString, err
		}

		regcred := &v1.Secret{
			TypeMeta: metav1.TypeMeta{
				Kind:       "Secret",
				APIVersion: "v1",
			},
			ObjectMeta: metav1.ObjectMeta{
				Name:      configs.Configuration.Docker.Name,
				Namespace: namespace,
			},
			Type: v1.SecretTypeDockerConfigJson,
			//Just put the string you want in, and when it is JSON encoded it is transformed to base64
			Data: map[string][]byte{
				".dockerconfigjson": []byte(configs.Configuration.Docker.Secret),
			},
		}
		_, err := kubernetesAPI.ClientSet.CoreV1().Secrets(namespace).Create(regcred)
		if err != nil {
			return EmptyString, err
		}
	} else if err != nil {
		return EmptyString, err
	} else {
		response = namespace + " already exists"
	}

	return response, nil
}

// Find takes a slice and looks for an element in it. If found it will
// return it's key, otherwise it will return -1 and a bool of false.
func find(slice []string, val string) (int, bool) {
	for i, item := range slice {
		if item == val {
			return i, true
		}
	}
	return -1, false
}
