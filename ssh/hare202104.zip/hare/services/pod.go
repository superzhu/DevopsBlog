package services

import (
	"hare/internal/kubernetes"
	"hare/log"
	v1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
)

func GetPodList(client *kubernetes.KubernetesAPI, namespace string) (*v1.PodList, error) {
	log.Logger.Infof("Getting list of all pods in the cluster namespace : %s", namespace)

	//list, err := client.ClientSet.CoreV1().Pods(namespace).List(context.TODO(), options)
	list, err := client.ClientSet.CoreV1().Pods(namespace).List(metav1.ListOptions{})

	return list, err
}
