package services

import (
	"hare/internal/kubernetes"
	v1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
)

//Handle kubernetes configmap operations
type ConfigmapService interface {
	GetDeployProfile(namespace string, configmap string) (*v1.ConfigMap, error)
}

func NewConfigmapService() ConfigmapService {
	return &configmapService{}
}

type configmapService struct {
}

//Get configmap in specified namespace
func (s *configmapService) GetDeployProfile(namespace string, configmap string) (*v1.ConfigMap, error) {
	kubernetesAPI, err := kubernetes.GetKubernetesAPI()
	if err != nil {
		return nil, err
	}

	return kubernetesAPI.ClientSet.CoreV1().ConfigMaps(namespace).Get(configmap, metav1.GetOptions{})
}
