package services

import (
	"fmt"
	"github.com/kataras/iris/v12"
	"hare/internal/kubernetes"
	"hare/log"
	"hare/services/container"
	"io"
	"os"
	"path/filepath"
	"time"
)

const (
	LOGDIR     = "LogDir"
	LOGFILEEXT = "txt"
	LOGTAREXT  = "tar.gz"
	LOGZIPEXT  = "zip"
)

//Download streaming log

type LogDownloadService interface {
	Download(ctx iris.Context, namespace string) (string, error)
}

func NewLogDownloadService() LogDownloadService {
	return &logDownloadService{}
}

type logDownloadService struct {
}

func (s *logDownloadService) Download(ctx iris.Context, namespace string) (string, error) {
	kubernetesAPI, err := kubernetes.GetKubernetesAPI()
	if err != nil {
		return EmptyString, err
	}

	list, err := GetPodList(kubernetesAPI, namespace)
	if err != nil {
		return EmptyString, err
	}
	logWorkingDirectory, err := createTempWorkingDirectory(LOGDIR, true)
	defer os.RemoveAll(logWorkingDirectory)
	if err != nil {
		return EmptyString, err
	}

	zipOutputDirectory, err := createTempWorkingDirectory(LOGDIR, true)
	defer os.RemoveAll(zipOutputDirectory)
	if err != nil {
		return EmptyString, err
	}

	//Iterate over pod list of specific namespace
	usePreviousLogs := false
	var logFiles = make([]string, 0)
	for _, item := range list.Items {
		podID := item.ObjectMeta.Name
		for _, containerItem := range item.Spec.Containers {
			containerID := containerItem.Name
			log.Logger.Infof("Get stream log from container: %s of pod: %v in namespace: %v", containerID, podID, namespace)
			logStream, err := container.GetLogFile(kubernetesAPI, namespace, podID, containerID, usePreviousLogs)
			if err != nil {
				return EmptyString, err
			}
			logFileName := getLogName(logWorkingDirectory, podID, containerID)
			handleDownload(logFileName, logStream)
			logFiles = append(logFiles, logFileName)
		}
	} //pods

	dt := time.Now()
	dateStr := dt.Format("20060102-150405")
	fileName := fmt.Sprintf("log_from_%s_on_%s.%s", namespace, dateStr, LOGZIPEXT)
	outputFile := filepath.Join(zipOutputDirectory, fileName)

	progress := func(archivePath string) {
		log.Logger.Infof("Zipping log file: %s", archivePath)
	}
	err = ArchiveFile(logWorkingDirectory, outputFile, progress)
	//err = Tarinate(logFiles, file)
	if err != nil {
		log.Logger.Errorf("Error while tarring/zipping local log files: %v", err)
		return EmptyString, err
	}

	err = ctx.SendFile(outputFile, fileName)

	if err != nil {
		log.Logger.Errorf("Error while running SendFile: %v", err)
		return EmptyString, err
	}

	return fileName, nil
}

func getLogName(logDir string, pod string, container string) string {
	//log-from-{containerName}-in-{podName}, for example logs-from-transproxy-in-transproxy-7f58964774-khvq5.txt
	logFile := fmt.Sprintf("log-from-%s-in-%s.%s", container, pod, LOGFILEEXT)
	return filepath.Join(logDir, logFile)
}

func handleDownload(logFileInPod string, result io.ReadCloser) {
	logfile, err := os.Create(logFileInPod)
	if err != nil {
		log.Logger.Errorf("Creating local log file has error: %v", err)
		return
	}
	defer result.Close()
	defer logfile.Close()

	_, err = io.Copy(logfile, result)
	if err != nil {
		log.Logger.Errorf("Copying log stream to local log file has error: %v", err)
		return
	}
}
