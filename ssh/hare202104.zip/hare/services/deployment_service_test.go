package services

import "testing"

func TestMapEqual(t *testing.T) {
	map_1 := map[string]interface{}{
		"image.repository":  "bitnami/rabbitmq",
		"rabbitmq.username": "guest",
		"rabbitmq.password": "guest",
		"replicaCount":      1,
	}

	map_2 := map[string]interface{}{
		"image.repository":  "bitnami/rabbitmq",
		"rabbitmq.username": "guest",
		"rabbitmq.password": "guest",
		"replicaCount":      1,
	}

	equal := inclusive(map_1, map_2)
	if equal {
		t.Log("two map equals test passed.")
	} else {
		t.Errorf("two map equals test failed, map1: %v, map2: %v", map_1, map_2)
	}
}

func TestMapInclusive(t *testing.T) {
	map_1 := map[string]interface{}{
		"image.repository":  "bitnami/rabbitmq",
		"rabbitmq.username": "guest",
		"rabbitmq.password": "guest",
		"replicaCount":      1,
	}

	map_2 := map[string]interface{}{
		"image.repository":  "bitnami/rabbitmq",
		"rabbitmq.password": "guest",
		"replicaCount":      1,
	}

	equal := inclusive(map_1, map_2)
	if equal {
		t.Log("map_1 contains all map_2 key/value pair")
	} else {
		t.Errorf("two map inclusive test failed, map1: %v, map2: %v", map_1, map_2)
	}
}

func TestMapNotInclusive(t *testing.T) {
	map_1 := map[string]interface{}{
		"image.repository":  "bitnami/rabbitmq",
		"rabbitmq.username": "guest",
		"rabbitmq.password": "guest",
		"replicaCount":      1,
	}

	map_2 := map[string]interface{}{
		"image.repository":  "bitnami/rabbitmq",
		"rabbitmq.password": "guest",
		"replicaCount":      2,
	}

	equal := inclusive(map_1, map_2)
	if !equal {
		t.Log("map_1 does not contain all map_2 key/value pair")
	} else {
		t.Errorf("two map inclusive test failed, map1: %v, map2: %v", map_1, map_2)
	}
}

func TestMapNotInclusive2(t *testing.T) {
	map_1 := map[string]interface{}{
		"image.repository":  "bitnami/rabbitmq",
		"rabbitmq.password": "guest",
		"replicaCount":      1,
	}

	map_2 := map[string]interface{}{
		"image.repository":  "bitnami/rabbitmq",
		"rabbitmq.username": "guest",
		"rabbitmq.password": "guest",
		"replicaCount":      1,
	}

	equal := inclusive(map_1, map_2)
	if !equal {
		t.Log("map_1 does not contain all map_2 key/value pair")
	} else {
		t.Errorf("two map inclusive test failed, map1: %v, map2: %v", map_1, map_2)
	}
}
