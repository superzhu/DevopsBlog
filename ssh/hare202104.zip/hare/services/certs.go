package services

import (
	"errors"
	"fmt"
	"hare/log"
	"io/ioutil"
	"path/filepath"
)

const (
	PRIVATEKEYEXT string = ".key"
)

type certContext struct {
	cert []byte
	key  []byte
}

//len(files) ==2
func setupServerCert(files []string) (*certContext, error) {
	if len(files) != 2 {
		return nil, errors.New(fmt.Sprintf("Only accept certificates/private key files for setupServerCert"))
	}

	var certFile string
	var keyFile string

	for _, item := range files {
		if filepath.Ext(item) == PRIVATEKEYEXT {
			keyFile = item
		} else {
			certFile = item
		}
	}

	if certFile == EmptyString || keyFile == EmptyString {
		return nil, errors.New(fmt.Sprintf("For setupServerCert, at lease on file extension is key"))
	}
	log.Logger.Infof("For setupServerCert,certificate=%s, key=%s", certFile, keyFile)

	certData, err := ioutil.ReadFile(certFile)
	if err != nil {
		certErr := fmt.Sprintf("In setupServerCert, read file: %s has error: %v", certFile, err)
		log.Logger.Errorf("In setupServerCert error: %v", certErr)
		return nil, errors.New(certErr)
	}

	keyData, err := ioutil.ReadFile(keyFile)
	if err != nil {
		certErr := fmt.Sprintf("In setupServerCert, read file: %s has error: %v", keyFile, err)
		log.Logger.Errorf("In setupServerCert error: %v", certErr)
		return nil, errors.New(certErr)
	}

	return &certContext{
		cert: certData,
		key:  keyData,
	}, nil
}
