package services

import (
	"github.com/kataras/iris/v12"
	"hare/log"
	"os"
)

//Download static log files

type StaticLogDownloadService interface {
	ListStaticLog(ctx iris.Context) (string, error)
}

func NewStaticLogDownloadService() StaticLogDownloadService {
	return &staticLogDownloadService{}
}

type staticLogDownloadService struct {
}

type HostLog struct {
	K8sNode Node
	Apps    map[string][]os.FileInfo
}

func (s *staticLogDownloadService) ListStaticLog(ctx iris.Context) (string, error) {
	log.Logger.Infof("Running ListStaticLog in staticlogdownload_service ...")

	// 1. Get configuration file number for each service
	logRotateService := NewLogrotateService()
	logrotate, err := logRotateService.GetConf(ctx)
	if err != nil {
		log.Logger.Errorf("Get logrotate configuration has error in staticlogdownload_service: %v", err)
		return EmptyString, err
	}

	// 2. Get kubernetes nodes
	nodes, err := getNodeList()
	if err != nil {
		log.Logger.Errorf("getNodeList has error: %v", err)
		return EmptyString, err
	}

	var hostLogFiles = make([]HostLog, 1)
	for _, node := range nodes {
		newhost := HostLog{}
		newhost.K8sNode = node

		hostLogFiles = append(hostLogFiles, newhost)
	}

	//var privatekey = filepath.Join(os.Getenv("HOME"), ".ssh", configs.Configuration.Server.PrivateKey)
	//configs.Configuration.Server.SshPort,  configs.Configuration.Server.SshUser

	log.Logger.Infof("kubernetes nodes: %v", logrotate)

	return EmptyString, nil
}
