package services

import (
	"fmt"
	"github.com/kataras/iris/v12"
	"github.com/pkg/errors"
	"hare/configs"
	"hare/internal/kubernetes"
	"hare/internal/sshclient"
	"hare/log"
	v1 "k8s.io/api/core/v1"
	k8serrors "k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/fields"
	"k8s.io/apimachinery/pkg/labels"
	"math/rand"
	"mime/multipart"
	"net"
	"os"
	"path"
	"path/filepath"
	"strconv"
	"strings"
	"time"
)

type FileUploadType string

// These are valid file upload type
const (
	FileUploadImages       FileUploadType = "Images"
	FileUploadEtcd         FileUploadType = "Etcd"
	FileUploadKubernetes   FileUploadType = "Kubernetes"
	FileUploadCertificates FileUploadType = "Certificates"
)

//Handle kubernetes file upload operations (interface)
type FileUploadService interface {
	FileUpload(ctx iris.Context) (string, error)
}

func NewFileUploadService() FileUploadService {
	return &fileUploadService{}
}

type fileUploadService struct {
}

type Node struct {
	hostIP       string             `json:"hostIP,omitempty"`
	targetFolder string             `json:"targetFolder,omitempty"`
	Ready        v1.ConditionStatus `json:"ready"`
	sshApi       *sshclient.SshApi  `json:"sshApi"`
}

func (s *fileUploadService) FileUpload(ctx iris.Context) (string, error) {
	if configs.Configuration.Deployment.Type != "ON-PREMISES" {
		ctx.StatusCode(iris.StatusForbidden)
		return EmptyString, errors.New("FileUpload only availabe when deployment type is ON-PREMISES")
	}

	fileuploadstr := ctx.GetHeader("fileuploadtype")
	log.Logger.Infof("File upload type header value: %v", fileuploadstr)
	if fileuploadstr == EmptyString {
		ctx.StatusCode(iris.StatusBadRequest)
		return EmptyString, errors.New("No fileuploadtype header")
	}

	fileuploadtype := FileUploadType(fileuploadstr)
	var response = ""
	var privatekey = filepath.Join(os.Getenv("HOME"), ".ssh", configs.Configuration.Server.PrivateKey)

	// store uploaded file in pod's temp subfolder
	tempWorkingDirectory, err := createTempWorkingDirectory(fileuploadstr, true)
	defer removeFolderInPod(tempWorkingDirectory)
	if err != nil {
		return EmptyString, err
	}

	_, err = ctx.UploadFormFiles(tempWorkingDirectory, beforeSave)
	if err != nil {
		ctx.StatusCode(iris.StatusInternalServerError)
		log.Logger.Warnf("Error while uploading: %v", err.Error())
		return EmptyString, err
	}

	//check validity of uploaded file
	var fileCount int
	filesInPod, err := FilePathWalkDir(tempWorkingDirectory)
	if fileuploadtype == FileUploadImages ||
		fileuploadtype == FileUploadEtcd ||
		fileuploadtype == FileUploadKubernetes {
		fileCount = 1
	} else if fileuploadtype == FileUploadCertificates {
		fileCount = 2
	}
	if len(filesInPod) != fileCount {
		ctx.StatusCode(iris.StatusBadRequest)
		return EmptyString, errors.New(fmt.Sprintf("For %s file upload type, can only upload %d file(s) each time", fileuploadstr, fileCount))
	}

	var nodes []Node
	results := make(chan error, 10)
	timeout := time.After(30 * time.Second)
	if fileuploadtype == FileUploadImages ||
		fileuploadtype == FileUploadEtcd ||
		fileuploadtype == FileUploadKubernetes {
		nodes, err = getNodeList()
		if err != nil {
			log.Logger.Errorf("getNodeList has error: %v", err)
			return EmptyString, err
		}

		for index, node := range nodes {
			sshApi, err := sshclient.DefaultSshApiSetup(node.hostIP, configs.Configuration.Server.SshPort,
				configs.Configuration.Server.SshUser, privatekey)
			if err != nil {
				log.Logger.Errorf("Connect to remote host has error: %v", err)
				return EmptyString, err
			}
			node.sshApi = sshApi

			//Get working directory in remote host
			targetFolder, err := createRemoteTempWorkingDirectory(fileuploadstr, sshApi, tempWorkingDirectory)
			node.targetFolder = targetFolder
			if err != nil {
				return EmptyString, err
			}
			nodes[index] = node
		}
	}

	switch fileuploadtype {
	case FileUploadImages:
		for _, node := range nodes {
			go func(node Node, filesInPod []string) {
				results <- runDockerLoad(node, filesInPod)
			}(node, filesInPod)
		}

		for i := 0; i < len(nodes); i++ {
			select {
			case res := <-results:
				if res != nil {
					return EmptyString, res
				}
			case <-timeout:
				log.Logger.Infof("Timed out!--- runDockerLoad")
			}
		}

		response = "Images file is being uploaded successfully."
	case FileUploadEtcd:
		etcdDir := filepath.Base(filesInPod[0])
		etcdDir = FilenameWithoutExtension(FilenameWithoutExtension(etcdDir))
		for _, node := range nodes {
			go func(node Node, filesInPod []string, etcdDir string) {
				results <- upgradeEtcd(node, filesInPod, etcdDir)
			}(node, filesInPod, etcdDir)
		}

		for i := 0; i < len(nodes); i++ {
			select {
			case res := <-results:
				if res != nil {
					return EmptyString, res
				}
			case <-timeout:
				log.Logger.Infof("Timed out!--- running ETCD upgrade")
			}
		}

		log.Logger.Infof("File upload type header value: %v, execute ETCD update logic.", fileuploadstr)
		response = "Etcd is upgraded successfully."
	case FileUploadKubernetes:
		log.Logger.Infof("File upload type header value: %v, execute Kubernetes update logic.", fileuploadstr)

		//kubernetes folder after extracting tar.gz file
		kubernetesDir := "kubernetes/server/bin"
		for _, node := range nodes {
			go func(node Node, filesInPod []string, kubernetesDir string) {
				results <- upgradeKubernetes(node, filesInPod, kubernetesDir)
			}(node, filesInPod, kubernetesDir)
		}

		for i := 0; i < len(nodes); i++ {
			select {
			case res := <-results:
				if res != nil {
					return EmptyString, res
				}
			case <-timeout:
				log.Logger.Infof("Timed out!--- running Kubernetes upgrade")
			}
		}

		response = "Kubernetes is upgraded successfully."
	case FileUploadCertificates:
		certContext, err := setupServerCert(filesInPod)
		if err != nil {
			log.Logger.Errorf("FileUploadCertificates has error: %v", err)
			return EmptyString, err
		}

		kubernetesAPI, err := kubernetes.GetKubernetesAPI()
		if err != nil {
			return EmptyString, err
		}

		secretName := configs.Configuration.Server.CustomerIngressSecret
		nsService := NewNamespaceService()
		namespaces, err := nsService.GetAll()

		for _, item := range namespaces {
			namespace := item.Name
			secret := &v1.Secret{
				TypeMeta: metav1.TypeMeta{
					Kind: "Secret",
				},
				ObjectMeta: metav1.ObjectMeta{
					Name:      secretName,
					Namespace: namespace,
				},
				Type: v1.SecretTypeTLS,
				Data: map[string][]byte{
					v1.TLSCertKey:       certContext.cert,
					v1.TLSPrivateKeyKey: certContext.key,
				},
			}

			existedSecret, err := kubernetesAPI.ClientSet.CoreV1().Secrets(namespace).Get(secretName, metav1.GetOptions{})

			if k8serrors.IsNotFound(err) {
				log.Logger.Infof("Create secret: %s in namespace: %s", secretName, namespace)
				_, err = kubernetesAPI.ClientSet.CoreV1().Secrets(namespace).Create(secret)
				if err != nil {
					log.Logger.Errorf("Create secrets has error: %v", err)
					return EmptyString, err
				}
			} else if existedSecret != nil {
				log.Logger.Infof("Update secret: %s in namespace: %s", secretName, namespace)
				_, err = kubernetesAPI.ClientSet.CoreV1().Secrets(namespace).Update(secret)
				if err != nil {
					log.Logger.Errorf("Update secrets has error: %v", err)
					return EmptyString, err
				}
			} else {
				log.Logger.Errorf("Get secrets has error: %v", err)
				return EmptyString, err
			}
		}

		response = "Create customer ingress secrets successfully"
		log.Logger.Infof("File upload type header value: %v, execute domain-related certificates/private key upload logic.", fileuploadstr)
	default:
		ctx.StatusCode(iris.StatusBadRequest)
		return EmptyString, errors.New("fileuploadtype header value is not correct, valid value are: Images,Etcd,Kubernetes,Certificates")
	}

	return response, nil
}

//Get host IP of all Kubernetes cluster nodes
func getNodeList() ([]Node, error) {
	kubernetesAPI, err := kubernetes.GetKubernetesAPI()
	if err != nil {
		return nil, err
	}

	// ListEverything is a list options used to list all resources without any filtering.
	var ListEverything = metav1.ListOptions{
		LabelSelector: labels.Everything().String(),
		FieldSelector: fields.Everything().String(),
	}
	nodeList, err := kubernetesAPI.ClientSet.CoreV1().Nodes().List(ListEverything)
	//log.Logger.Infof("Kubernetes cluster node list: %v", nodeList)
	if err != nil {
		return nil, err
	}

	var nodes = make([]Node, 0)
	for _, nodeItem := range nodeList.Items {
		newNode := Node{}
		newNode.hostIP = getNodeInternalIP(nodeItem, v1.NodeInternalIP)
		newNode.Ready = getNodeConditionStatus(nodeItem, v1.NodeReady)
		if net.ParseIP(newNode.hostIP) == nil {
			log.Logger.Errorf("node internalIP is not correct: %v", newNode.hostIP)
			continue
		}
		nodes = append(nodes, newNode)
	}

	log.Logger.Infof("Kubernetes cluster nodes: %v", nodes)
	return nodes, nil
}

func getNodeInternalIP(node v1.Node, nodeAddressType v1.NodeAddressType) string {
	for _, nodeAddress := range node.Status.Addresses {
		if nodeAddress.Type == nodeAddressType {
			return nodeAddress.Address
		}
	}
	return "Unknown"
}

func getNodeConditionStatus(node v1.Node, conditionType v1.NodeConditionType) v1.ConditionStatus {
	for _, condition := range node.Status.Conditions {
		if condition.Type == conditionType {
			return condition.Status
		}
	}
	return v1.ConditionUnknown
}

//Create different working directory under /tmp folder based on file upload type
func createTempWorkingDirectory(fileuploadtype string, local bool) (string, error) {
	var projectPath string
	tempdir := os.TempDir()
	// loop patten : repeat ... until
	for {
		append := rand.Intn(1000)
		projectPath = filepath.Join(tempdir, fileuploadtype, strconv.Itoa(append))
		if !configs.DirExists(projectPath) {
			break
		}
	}

	if local {
		log.Logger.Infof("Creating temp working directory %v ... in pods", projectPath)
		err := os.MkdirAll(projectPath, 0755)
		if err != nil {
			return EmptyString, errors.Wrap(err, "Cannot create subfolder under /tmp.")
		}
	}

	return projectPath, nil
}

func createRemoteTempWorkingDirectory(fileuploadtype string, sshApi *sshclient.SshApi, localWorkingDirectory string) (string, error) {
	var targetFolder = localWorkingDirectory
	for {
		remoteCmd := fmt.Sprintf("ls -l %s", targetFolder)
		stdout, stderr, err := sshApi.Run(remoteCmd)

		if err != nil {
			log.Logger.Infof("Run command : %v has error %v on remote host %v", remoteCmd, err, sshApi.Host)
			remoteCmd = fmt.Sprintf("mkdir -p %s", targetFolder)
			stdout, stderr, err = sshApi.Run(remoteCmd)
			if err != nil {
				log.Logger.Errorf("Cannot create folder on host: %s, error: %v", sshApi.Host, err)
				return EmptyString, err
			}

			log.Logger.Infof("Create folder %s on host %s, stdout: %v; stderr: %v",
				targetFolder, sshApi.Host, stdout, stderr)
			break
		} else {
			log.Logger.Infof("%s already exists on remote host %s", targetFolder, sshApi.Host)
			targetFolder, err = createTempWorkingDirectory(fileuploadtype, false)
			if err != nil {
				return EmptyString, err
			}
		}
	}

	return targetFolder, nil
}

func beforeSave(ctx iris.Context, file *multipart.FileHeader) {
	ip := ctx.RemoteAddr()
	log.Logger.Infof("File %v is uploaded from pod to remote host: %v", file.Filename, ip)
}

func FilePathWalkDir(path string) ([]string, error) {
	var files []string
	err := filepath.Walk(path, func(path string, info os.FileInfo, err error) error {
		if !info.IsDir() {
			files = append(files, path)
		}
		return nil
	})
	return files, err
}

func removeFolderInPod(path string) {
	os.RemoveAll(path)
}

func copyAndExtractTar(node Node, filesInPod []string) (string, error) {
	sourceFile := filesInPod[0]
	targetFile := filepath.Join(node.targetFolder, filepath.Base(filesInPod[0]))
	err := node.sshApi.CopyToRemote(sourceFile, targetFile)
	if err != nil {
		log.Logger.Errorf("Copy pod file %s to host %s : %s has error %v", sourceFile, node.hostIP, node.targetFolder, err)
		return EmptyString, err
	}
	log.Logger.Infof("Has copied file %s to host %s : %s", sourceFile, node.hostIP, node.targetFolder)

	extractTar := fmt.Sprintf("tar -xzvf %s -C %s", targetFile, node.targetFolder)
	stdout, stderr, err := node.sshApi.Run(extractTar)
	if err != nil {
		log.Logger.Errorf("Run remote command %s on host: %s has errors: %v", extractTar, node.hostIP, err)
		return EmptyString, err
	}
	log.Logger.Infof("Run remote command %s on host: %s. stdout: %v, stderr: %v",
		extractTar, node.hostIP, stdout, stderr)

	return stdout, nil
}

func runDockerLoad(node Node, filesInPod []string) error {
	stdout, err := copyAndExtractTar(node, filesInPod)
	if err != nil {
		return err
	}
	tarFiles := strings.Split(stdout, "\r\n")
	log.Logger.Infof("docker load following files: %v on host %s", tarFiles, node.hostIP)

	commands := make([]string, 0)
	for _, dockerItem := range tarFiles {
		if dockerItem == EmptyString {
			continue
		}

		dockerTar := filepath.Join(node.targetFolder, dockerItem)
		dockerLoadCommand := fmt.Sprintf("docker load -i %s", dockerTar)

		commands = append(commands, dockerLoadCommand)
	}

	removeTargetFolder := fmt.Sprintf("rm -rf %s", node.targetFolder)
	commands = append(commands, removeTargetFolder)

	for _, cmd := range commands {
		stdout, stderr, err := node.sshApi.Run(cmd)
		if err != nil {
			return err
		}
		log.Logger.Infof("Run Command: %s, stdout: %s, stderr: %s on host: %s",
			cmd, stdout, stderr, node.hostIP)
	}

	return nil
}

func upgradeEtcd(node Node, filesInPod []string, etcdDir string) error {
	_, err := copyAndExtractTar(node, filesInPod)
	if err != nil {
		return err
	}
	etcdDir = filepath.Join(node.targetFolder, etcdDir)
	log.Logger.Infof("Copy etcd,etcdctl from folder %s to /usr/local/bin on host: %s", etcdDir, node.hostIP)
	etcds := filepath.Join(etcdDir, "{etcd,etcdctl}")
	cpEtcds := fmt.Sprintf("cp %s /usr/local/bin", etcds)
	removeTargetFolder := fmt.Sprintf("rm -rf %s", node.targetFolder)

	commands := []string{
		"systemctl stop etcd",
		cpEtcds,
		"systemctl start etcd",
		removeTargetFolder,
	}

	for _, cmd := range commands {
		stdout, stderr, err := node.sshApi.Run(cmd)
		if err != nil {
			return err
		}
		log.Logger.Infof("Run Command: %s, stdout: %s, stderr: %s on host: %s",
			cmd, stdout, stderr, node.hostIP)
	}

	return nil
}

func upgradeKubernetes(node Node, filesInPod []string, kubernetesDir string) error {
	_, err := copyAndExtractTar(node, filesInPod)
	if err != nil {
		return err
	}
	kubernetesDir = filepath.Join(node.targetFolder, kubernetesDir)
	log.Logger.Infof("Copy kubeadm kube-apiserver kube-controller-manager kubectl kubelet kube-proxy kube-scheduler from folder %s to /usr/local/bin on host: %s",
		kubernetesDir, node.hostIP)

	kubernetes := filepath.Join(kubernetesDir, "{kubeadm,kube-apiserver,kube-controller-manager,kubectl,kubelet,kube-proxy,kube-scheduler}")
	cpKubernetes := fmt.Sprintf("cp %s /usr/local/bin", kubernetes)
	removeTargetFolder := fmt.Sprintf("rm -rf %s", node.targetFolder)

	commands := []string{
		"systemctl stop kube-apiserver kube-controller-manager kubelet kube-proxy kube-scheduler",
		cpKubernetes,
		"systemctl start kube-apiserver kube-controller-manager kubelet kube-proxy kube-scheduler",
		removeTargetFolder,
	}

	for _, cmd := range commands {
		stdout, stderr, err := node.sshApi.Run(cmd)
		if err != nil {
			return err
		}
		log.Logger.Infof("Run Command: %s, stdout: %s, stderr: %s on host: %s",
			cmd, stdout, stderr, node.hostIP)
	}

	return nil
}

func FilenameWithoutExtension(fn string) string {
	return strings.TrimSuffix(fn, path.Ext(fn))
}
