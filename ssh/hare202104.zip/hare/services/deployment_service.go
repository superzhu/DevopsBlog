package services

import (
	"encoding/json"
	"fmt"
	"hare/configs"
	"hare/internal/kubernetes"
	"hare/log"
	v1 "k8s.io/api/apps/v1"
	apiv1 "k8s.io/api/core/v1"
	"k8s.io/apimachinery/pkg/api/errors"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"os"
	"os/exec"
	"path/filepath"
	"reflect"
	"strings"
)

const (
	EmptyString string = ""
	//ConfigMap name in each namespace for storing variable deployment options
	ProfileCMName string = "app-deploy-options"
	DevelopNs     string = "develop"
	ShellToUse    string = "sh"
)

type Action int

const (
	INTACT Action = iota
	CREATE
	UPDATE
)

//Handle kubernetes deployment operations
type DeploymentService interface {
	GetDeployments(namespace string) (*v1.DeploymentList, error)
	GetStatefulSetList(namespace string) (*v1.StatefulSetList, error)
	Update(namespace string, newProfile map[string]map[string]interface{}) (string, error)
	UndeployServices(namespace string, serviceNames []string) (string, error)
}

// NewNamespaceService returns the default namespace service.
func NewDeploymentService() DeploymentService {
	return &deploymentService{}
}

type deploymentService struct {
}

//Return all deployments in input namespace.
func (s *deploymentService) GetDeployments(namespace string) (*v1.DeploymentList, error) {
	kubernetesAPI, err := kubernetes.GetKubernetesAPI()
	if err != nil {
		return nil, err
	}

	return kubernetesAPI.ClientSet.AppsV1().Deployments(namespace).List(metav1.ListOptions{})
}

//Return all StatefulSetList in input namespace.
func (s *deploymentService) GetStatefulSetList(namespace string) (*v1.StatefulSetList, error) {
	kubernetesAPI, err := kubernetes.GetKubernetesAPI()
	if err != nil {
		return nil, err
	}

	return kubernetesAPI.ClientSet.AppsV1().StatefulSets(namespace).List(metav1.ListOptions{})
}

func (s *deploymentService) Update(namespace string, newProfile map[string]map[string]interface{}) (string, error) {
	if len(newProfile) == 0 {
		return "no input profile", nil
	}

	kubernetesAPI, err := kubernetes.GetKubernetesAPI()
	if err != nil {
		return EmptyString, err
	}

	var storedJson map[string]string
	var action Action = INTACT
	var deployed strings.Builder
	var undeployed strings.Builder

	deployed.WriteString(EmptyString)
	undeployed.WriteString(EmptyString)

	// Retrieve ProfileCMName configmap in input namespace
	storedConfigmap, err := kubernetesAPI.ClientSet.CoreV1().ConfigMaps(namespace).Get(ProfileCMName, metav1.GetOptions{})
	if errors.IsNotFound(err) {
		log.Logger.Warnf("configmap: %v does not exist in namespace: %v", ProfileCMName, namespace)

		//store new input profile here
		storedJson = make(map[string]string)
		for key, value := range newProfile {
			addMapItem(storedJson, key, value)
			deployed.WriteString(key + ",")
		}
		action = CREATE
	} else if err != nil {
		return EmptyString, err
	} else {
		// compare stored profile and new profile
		storedJson = storedConfigmap.Data
		if storedJson == nil {
			storedJson = make(map[string]string)
		}
		for key, inputMap := range newProfile {
			cmMap := make(map[string]interface{})
			if jsonStr, exist := storedJson[key]; exist {
				err = json.Unmarshal([]byte(jsonStr), &cmMap)
				if err != nil {
					log.Logger.Warnf("Unmarshal JSON to map has error: %v", err.Error())
				}
				equal := inclusive(cmMap, inputMap)
				if equal {
					delete(newProfile, key)
					undeployed.WriteString(key + ",")
				} else {
					//update cmMap based on inputMap
					addMapItem(storedJson, key, inputMap)
					action = UPDATE
					deployed.WriteString(key + ",")
				}
			} else {
				// if key from inputMap does not exist in configmap, add it to configmap to store
				addMapItem(storedJson, key, inputMap)
				action = UPDATE
				deployed.WriteString(key + ",")
			}
		}
	}

	// run helm chart to deploy applications based on newProfile
	wd, err := getWorkingDirectory()
	if err != nil {
		return EmptyString, err
	}
	runHelmChart(wd, namespace, newProfile)

	if action == CREATE {
		_, err = kubernetesAPI.ClientSet.CoreV1().ConfigMaps(namespace).Create(createConfigMap(storedJson))
		if err != nil {
			log.Logger.Errorf("Creating configmap has error: %v", err.Error())
		}
	} else if action == UPDATE {
		_, err = kubernetesAPI.ClientSet.CoreV1().ConfigMaps(namespace).Update(createConfigMap(storedJson))
		if err != nil {
			log.Logger.Errorf("Creating configmap has error: %v", err.Error())
		}
	}

	return getResponse(deployed, undeployed), nil
}

func getResponse(deployed strings.Builder, undeployed strings.Builder) string {
	var response string
	if len(deployed.String()) != 0 {
		response = "Deployed apps: " + deployed.String()[:(len(deployed.String())-1)]
	}
	if len(undeployed.String()) != 0 {
		response = response + " Undeployed apps due to same profile with previous ones: " + undeployed.String()[:(len(undeployed.String())-1)]
	}

	return response
}

func createConfigMap(storedJson map[string]string) *apiv1.ConfigMap {
	configMap := &apiv1.ConfigMap{
		TypeMeta: metav1.TypeMeta{
			Kind:       "ConfigMap",
			APIVersion: "v1",
		},
		ObjectMeta: metav1.ObjectMeta{
			Name: ProfileCMName,
		},
		Data: storedJson,
	}

	return configMap
}

func addMapItem(container map[string]string, key string, value map[string]interface{}) {
	// convert map to JSON
	data, err := json.Marshal(value)
	if err != nil {
		log.Logger.Warnf("Marshal map to JSON has error: %v", err.Error())
	} else {
		jsonStr := string(data)
		container[key] = jsonStr
	}
}

// if all key/value from inputMap are contained in cmMap, return true
func inclusive(cmMap map[string]interface{}, inputMap map[string]interface{}) bool {
	equal := reflect.DeepEqual(cmMap, inputMap)
	if equal {
		return true
	}

	for key, value := range inputMap {
		if cmValue, exist := cmMap[key]; exist {
			equal = reflect.DeepEqual(cmValue, value)
			if !equal {
				return false
			}
		} else {
			return false
		}
	}

	return true
}

// helm chart working directory
func getWorkingDirectory() (string, error) {
	homedir, err := os.UserHomeDir()
	if err != nil {
		return EmptyString, err
	}
	projectPath := filepath.Join(homedir, configs.Configuration.Helm.ProjectName)

	switch configs.Configuration.Deployment.Type {
	case "CLOUD":
		if _, err := os.Stat(projectPath); os.IsNotExist(err) {
			log.Logger.Infof("%v does not exist, create it using git clone command", projectPath)
			err := os.Chdir(homedir)
			if err != nil {
				return EmptyString, err
			}

			clone := filepath.Join(configs.Configuration.Helm.CloneCommand, configs.Configuration.Helm.ProjectName)
			clone = clone + ".git"
			cmd := exec.Command(ShellToUse, "-c", clone)
			out, err := cmd.CombinedOutput()
			if err != nil {
				return EmptyString, err
			}
			log.Logger.Infof("Run git clone command %v in path %v, command output %v", clone, homedir, string(out))
		} else {
			log.Logger.Infof("%v exists, update it using git pull command", projectPath)
			err := os.Chdir(projectPath)
			if err != nil {
				return EmptyString, err
			}

			cmd := exec.Command(ShellToUse, "-c", configs.Configuration.Helm.PullCommand)
			out, err := cmd.CombinedOutput()
			if err != nil {
				return EmptyString, err
			}
			log.Logger.Infof("Run git pull command %v in path %v, command output %v", configs.Configuration.Helm.PullCommand, projectPath, string(out))
		}
	case "ON-PREMISES":
		log.Logger.Infof("Deployment type is: %v in getWorkingDirectory(), not running git pull command", configs.Configuration.Deployment.Type)
	default:
		log.Logger.Infof("Deployment type is not correct: %v in getWorkingDirectory()", configs.Configuration.Deployment.Type)
	}

	projectPath = filepath.Join(projectPath, "helm3")
	err = os.Chdir(projectPath)
	if err != nil {
		return EmptyString, err
	}

	return projectPath, nil
}

func runHelmChart(wd string, namespace string, newProfile map[string]map[string]interface{}) {
	log.Logger.Infof("Run Helm Charts in directory %v against namespace %v", wd, namespace)
	for release, inputMap := range newProfile {
		helmCommand := "helm upgrade " + release
		helmCommand = helmCommand + " ./" + release
		helmCommand = helmCommand + " --debug --install"
		helmCommand = helmCommand + " --namespace=" + namespace

		for key, value := range inputMap {
			str := fmt.Sprintf("%v", value)
			helmCommand = helmCommand + " --set " + key + "=" + str
		}

		relativeFilePath, err := getChartConfigFile(wd, namespace, release)
		if err != nil {
			log.Logger.Errorf("Cannot get helm chart configuration file %v for helm command %v", err.Error(), helmCommand)
		} else {
			helmCommand = helmCommand + " -f " + relativeFilePath
			cmd := exec.Command(ShellToUse, "-c", helmCommand)
			out, err := cmd.CombinedOutput()
			if err != nil {
				log.Logger.Errorf("Run helm command has errors, command: %v, error: %v", helmCommand, err.Error())
			} else {
				log.Logger.Infof("Helm command: %v, its output: %v ", helmCommand, string(out))
			}
		}
	}
}

// get helm chart configuration file, relative to current working directory
func getChartConfigFile(wd string, namespace string, app string) (string, error) {
	fileName := "values-" + namespace + ".yaml"
	if namespace == DevelopNs {
		fileName = "values.yaml"
	}

	filePath := filepath.Join(wd, app, fileName)
	if _, err := os.Stat(filePath); os.IsNotExist(err) {
		// fallthrough to values.yaml
		fileName = "values.yaml"
		filePath = filepath.Join(wd, app, fileName)
		if _, err := os.Stat(filePath); os.IsNotExist(err) {
			return EmptyString, err
		}
	}

	return filepath.Join(app, fileName), nil
}

//undeploy all services specified in slice: serviceNames
func (s *deploymentService) UndeployServices(namespace string, serviceNames []string) (string, error) {
	if len(serviceNames) == 0 {
		return "no service name to be undeployed", nil
	}

	kubernetesAPI, err := kubernetes.GetKubernetesAPI()
	if err != nil {
		return EmptyString, err
	}

	var nonexist strings.Builder
	var undeployed strings.Builder

	nonexist.WriteString(EmptyString)
	undeployed.WriteString(EmptyString)

	// Retrieve ProfileCMName configmap in input namespace
	storedConfigmap, err := kubernetesAPI.ClientSet.CoreV1().ConfigMaps(namespace).Get(ProfileCMName, metav1.GetOptions{})
	if errors.IsNotFound(err) {
		log.Logger.Warnf("configmap: %v does not exist in namespace: %v", ProfileCMName, namespace)
		return EmptyString, err
	} else if err != nil {
		return EmptyString, err
	} else {
		storedJson := make(map[string]string)
		storedJson = storedConfigmap.Data
		log.Logger.Infof("current Kubernetes configmap: %v", storedJson)
		log.Logger.Infof("input service names to be Undeployed: %v", serviceNames)

		for _, serviceName := range serviceNames {
			if _, exist := storedJson[serviceName]; exist {
				delete(storedJson, serviceName)
				undeployed.WriteString(serviceName + ",")
				runHelmDelete(namespace, serviceName)
			} else {
				log.Logger.Infof("service %v is not deployed in namespace %v", serviceName, namespace)
				nonexist.WriteString(serviceName + ",")
			}
		}

		_, err = kubernetesAPI.ClientSet.CoreV1().ConfigMaps(namespace).Update(createConfigMap(storedJson))
		if err != nil {
			log.Logger.Errorf("Creating configmap has error: %v", err.Error())
		}
	}

	var response string
	if len(undeployed.String()) != 0 {
		response = "Undeployed apps: " + undeployed.String()[:(len(undeployed.String())-1)]
	}
	if len(nonexist.String()) != 0 {
		response = response + " ;Following services are not deleted: " + nonexist.String()[:(len(nonexist.String())-1)]
	}
	return response, nil
}

func runHelmDelete(namespace string, service string) {
	log.Logger.Infof("Undeloy service %v from namespace %v through helm command", service, namespace)
	helmCommand := "helm delete " + service
	helmCommand = helmCommand + " --debug --namespace=" + namespace

	cmd := exec.Command(ShellToUse, "-c", helmCommand)
	out, err := cmd.CombinedOutput()
	if err != nil {
		log.Logger.Errorf("Run helm command has errors, command: %v, error: %v", helmCommand, err.Error())
	} else {
		log.Logger.Infof("Helm command: %v, its output: %v ", helmCommand, string(out))
	}
}
