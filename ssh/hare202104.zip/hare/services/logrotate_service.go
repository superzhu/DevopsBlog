package services

import (
	"bufio"
	"fmt"
	"github.com/kataras/iris/v12"
	"hare/configs"
	"hare/internal/sshclient"
	"hare/log"
	"hare/web/models"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
)

const (
	FileLog         string = "Logs"
	RemoteLogFolder string = "/etc/logrotate.d"
	LogRotateFile   string = "k8s-rotator.conf"
	KeyRotate       string = "rotate"
	KeyMaxsize      string = "maxsize"
)

var once sync.Once
var instance *logrotateService

// logrotate configuration file parse and update
type LogrotateService interface {
	GetConf(ctx iris.Context) (models.LogrotateVO, error)
	UpdateConf(ctx iris.Context, newConf models.LogrotateVO) (string, error)
}

func NewLogrotateService() LogrotateService {
	once.Do(func() {
		fmt.Println("Create NewLogrotateService")
		instance = &logrotateService{}
	})

	return instance
}

type logrotateService struct {
}

// lock mutex
var lock = &sync.Mutex{}
var conf models.LogrotateVO
var txtlines []string
var emptyConf models.LogrotateVO //zero valued structure
var cacheInMemory = false

func (s *logrotateService) GetConf(ctx iris.Context) (models.LogrotateVO, error) {
	if cacheInMemory {
		log.Logger.Infof("GetConf service ---Return logrotate configuration from memory: %s", conf)
		return conf, nil
	} else {
		lock.Lock()
		defer lock.Unlock()

		//1 copy get kubernetes node list
		nodes, err := getNodeList()
		if err != nil {
			log.Logger.Errorf("getNodeList has error: %v", err)
			return emptyConf, err
		}
		log.Logger.Infof("Kubernetes nodes: %v", nodes)

		//2 copy logrotate configuration file from one of kubernetes node to local
		tempWorkingDirectory, err := createTempWorkingDirectory(FileLog, true)
		defer os.RemoveAll(tempWorkingDirectory)
		if err != nil {
			return emptyConf, err
		}
		localFile, err := copyFromRemoteToLocal(tempWorkingDirectory, nodes[0])
		if err != nil {
			return emptyConf, err
		}

		// 3 parse logrotate configuration file
		parseLogRotate(localFile)
		log.Logger.Infof("GetConf service ---Return logrotate configuration by reading configuration file: %s", conf)
		return conf, nil
	}
}

func (s *logrotateService) UpdateConf(ctx iris.Context, newConf models.LogrotateVO) (string, error) {
	if !cacheInMemory {
		_, err := s.GetConf(ctx)
		if err != nil {
			log.Logger.Errorf("GetConf has error: %v", err)
			return EmptyString, err
		}
	}

	lock.Lock()
	defer lock.Unlock()

	tempWorkingDirectory, err := createTempWorkingDirectory(FileLog, true)
	defer os.RemoveAll(tempWorkingDirectory)
	if err != nil {
		return EmptyString, err
	}

	// Generate logrotate configuration file in pod
	localfile, err := s.generateLocalRotator(ctx, newConf, tempWorkingDirectory)
	if err != nil {
		log.Logger.Errorf("Generate logrotate configuration file has error: %v", err)
		return EmptyString, err
	}

	// Copy generated logrotate configuration file from pod to nodes
	err = copyToRemoteNode(localfile)
	if err != nil {
		log.Logger.Errorf("Copy logrotate configuration file to nodes has error: %v", err)
		return EmptyString, err
	}

	conf = newConf
	return "Update logrotate configuration successfully.", nil
}

func copyFromRemoteToLocal(tempWorkingDirectory string, node Node) (string, error) {
	var privatekey = filepath.Join(os.Getenv("HOME"), ".ssh", configs.Configuration.Server.PrivateKey)
	var remoteFile = filepath.Join(RemoteLogFolder, LogRotateFile, )
	var localFile = filepath.Join(tempWorkingDirectory, LogRotateFile)

	scpCommand := fmt.Sprintf("scp -p -o StrictHostKeyChecking=no -i %s %s@%s:%s %s", privatekey,
		configs.Configuration.Server.SshUser,
		node.hostIP, remoteFile, localFile)
	cmd := exec.Command(ShellToUse, "-c", scpCommand)
	out, err := cmd.CombinedOutput()
	if err != nil {
		log.Logger.Errorf(" Run scp command: %s has error: %v, CombinedOutput: %v ", scpCommand, err, string(out))
		return EmptyString, err
	}
	log.Logger.Infof("   Run scp Command: %s on host: %s, its output is: CombinedOutput: %v",
		scpCommand, node.hostIP, string(out) )

	return localFile, err
}

func parseLogRotate(localFile string) {
	log.Logger.Infof("Parse logrotate configuration file: %s", localFile)
	file, err := os.Open(localFile)
	defer file.Close()
	if err != nil {
		log.Logger.Errorf("failed opening file: %s", err)
	}

	scanner := bufio.NewScanner(file)
	scanner.Split(bufio.ScanLines)

	newlines := make([]string, 0)

	for scanner.Scan() {
		textline := scanner.Text()
		if strings.Contains(textline, KeyRotate) {
			words := strings.Fields(textline)
			// Convert string to int.
			number, _ := strconv.ParseInt(words[1], 10, 0)
			conf.Rotate = number
		} else if strings.Contains(textline, KeyMaxsize) {
			words := strings.Fields(textline)
			conf.Maxsize = words[1]
		}
		newlines = append(newlines, textline)
	}

	txtlines = newlines
	log.Logger.Infof("parseLogRotate -- txtlines: %s", txtlines)
	cacheInMemory = true
}

func (s *logrotateService) generateLocalRotator(ctx iris.Context, newConf models.LogrotateVO,
	tempWorkingDirectory string) (string, error) {
	// Generate new logrotate configuration file based on input new configuration
	for idx, textline := range txtlines {
		if strings.Contains(textline, KeyRotate) {
			textline = strings.Replace(textline, strconv.FormatInt(conf.Rotate, 10), strconv.FormatInt(newConf.Rotate, 10), 1)
			txtlines[idx] = textline
		} else if strings.Contains(textline, KeyMaxsize) {
			textline = strings.Replace(textline, conf.Maxsize, newConf.Maxsize, 1)
			txtlines[idx] = textline
		}
	}

	var localFile = filepath.Join(tempWorkingDirectory, LogRotateFile)
	f, err := os.OpenFile(localFile,
		os.O_RDWR|os.O_APPEND|os.O_CREATE, 0644)
	defer f.Close()
	if err != nil {
		return EmptyString, err
	}

	// writes a slice of strings to a file, one per line
	sep := "\n"
	datawriter := bufio.NewWriter(f)
	for _, data := range txtlines {
		_, _ = datawriter.WriteString(data + sep)
	}
	datawriter.Flush()

	log.Logger.Infof("generateLocalRotator -- file contents: %s", txtlines)

	return localFile, nil
}

func copyToRemoteNode(localfile string) error {
	var remotefile = filepath.Join(RemoteLogFolder, LogRotateFile)
	var privatekey = filepath.Join(os.Getenv("HOME"), ".ssh", configs.Configuration.Server.PrivateKey)

	nodes, err := getNodeList()
	if err != nil {
		log.Logger.Errorf("getNodeList has error: %v", err)
		return err
	}

	for index, node := range nodes {
		sshApi, err := sshclient.DefaultSshApiSetup(node.hostIP, configs.Configuration.Server.SshPort,
			configs.Configuration.Server.SshUser, privatekey)
		if err != nil {
			log.Logger.Errorf("Connect to remote host has error: %v", err)
			return err
		}
		node.sshApi = sshApi
		nodes[index] = node
	}

	for _, node := range nodes {
		err := node.sshApi.CopyToRemote(localfile, remotefile)
		if err != nil {
			log.Logger.Errorf("Copy pod file %s to host %s : %s has error %v", localfile, node.hostIP, remotefile, err)
			return err
		}
	}

	return nil
}
