package main

import (
	"fmt"
	"github.com/kataras/iris/v12"
	"github.com/kataras/iris/v12/hero"
	"github.com/kataras/iris/v12/middleware/basicauth"
	"github.com/pkg/errors"
	"github.com/spf13/pflag"
	"github.com/spf13/viper"
	"hare/configs"
	"hare/log"
	"hare/services"
	"hare/web/routes"
	"net/http"
	"os"
	"strconv"
	"time"
)

//entry point of hare application
// iris session example: https://github.com/kataras/iris/issues/1338
func main() {
	var configPath *string = pflag.StringP("config", "c", "", "config file path.")
	pflag.Parse()

	// Load application configuration
	err := loadConfig(*configPath)
	if err != nil {
		fmt.Printf("%+v\n", err)
		os.Exit(1)
	}

	app := iris.New()
	log.ConfigureLog(app)
	log.Logger.Infof("Application Configuration input path: %s", *configPath)

	buildRouter(app)

	addr := ":" + strconv.Itoa(configs.Configuration.Server.Port)
	err = app.Run(iris.Addr(addr),
		// skip err server closed when CTRL/CMD+C pressed:
		iris.WithoutServerError(iris.ErrServerClosed),
		iris.WithCharset("UTF-8"),
		iris.WithoutPathCorrectionRedirection,
		// enables faster json serialization and more:
		iris.WithOptimizations)
	if err != nil {
		fmt.Printf("%+v\n", err)
		os.Exit(1)
	}
}

// loads the application configurations
func loadConfig(filename string) error {
	fang := viper.New()
	err := configs.InitConfig(filename, fang)
	if err != nil {
		return errors.Wrap(err, "error in application configuration initialization.")
	}
	return nil
}

func buildRouter(app *iris.Application) {
	authConfig := basicauth.Config{
		Users:   map[string]string{"appid": configs.Configuration.Server.Appid},
		Realm:   "Authorization Required", // defaults to "Authorization Required"
		Expires: time.Duration(30) * time.Minute,
	}

	authentication := basicauth.New(authConfig)

	//Create our Namespace service, we will bind it to the namespace app's dependencies.
	namespaceService := services.NewNamespaceService()
	hero.Register(namespaceService)

	// Serve our routes with hero handlers.
	app.PartyFunc(configs.Configuration.Server.RoutePrefix, func(r iris.Party) {
		r.Get("/namespaces", authentication, hero.Handler(routes.Namespaces))
		r.Post("/namespaces/{namespace:string}", authentication, hero.Handler(routes.Create))
		r.Get("/healthz", healthHandler)
		r.Get("/readiness", readinessHandler)
	})

	deploymentService := services.NewDeploymentService()
	hero.Register(deploymentService)

	app.PartyFunc(configs.Configuration.Server.RoutePrefix, func(r iris.Party) {
		r.Get("/namespaces/{namespace:string}/deployments", authentication, hero.Handler(routes.List))
		r.Post("/namespaces/{namespace:string}/deployments", authentication, hero.Handler(routes.Update))
		r.Delete("/namespaces/{namespace:string}/deployments", authentication, hero.Handler(routes.UndeployServices))
	})

	configmapService := services.NewConfigmapService()
	hero.Register(configmapService)

	app.PartyFunc(configs.Configuration.Server.RoutePrefix, func(r iris.Party) {
		r.Get("/namespaces/{namespace:string}/configmaps/{configmap:string}", authentication, hero.Handler(routes.Configmap))
	})

	fileUploadService := services.NewFileUploadService()
	hero.Register(fileUploadService)

	maxSize := configs.Configuration.Server.MaxRequestBodySize << 20 //1G
	app.PartyFunc(configs.Configuration.Server.RoutePrefix, func(r iris.Party) {
		r.Post("/file/upload", authentication, iris.LimitRequestBodySize(maxSize), hero.Handler(routes.FileUpload))
		//r.Post("/log/file/upload",  iris.LimitRequestBodySize(maxSize), hero.Handler(routes.FileUpload))
	})

	logRotateService := services.NewLogrotateService()
	hero.Register(logRotateService)

	app.PartyFunc(configs.Configuration.Server.RoutePrefix, func(r iris.Party) {
		r.Get("/log/config", authentication, hero.Handler(routes.GetConf))
		r.Post("/log/config", authentication, hero.Handler(routes.UpdateConf))
	})

	/*logDownloadService := services.NewLogDownloadService()
	hero.Register(logDownloadService)

	app.PartyFunc(configs.Configuration.Server.RoutePrefix, func(r iris.Party) {
		r.Get("/log/file/{namespace:string}", authentication, hero.Handler(routes.Download))
	})*/

	staticLogDownloadService := services.NewStaticLogDownloadService()
	hero.Register(staticLogDownloadService)
	app.PartyFunc(configs.Configuration.Server.RoutePrefix, func(r iris.Party) {
		r.Get("/log/list", authentication, hero.Handler(routes.ListStaticLog))
	})
}

func healthHandler(ctx iris.Context) {
	_, err := ctx.Writef(http.StatusText(http.StatusOK))
	if err != nil {
		ctx.StatusCode(http.StatusInternalServerError)
	}

}

func readinessHandler(ctx iris.Context) {
	_, err := ctx.Writef(http.StatusText(http.StatusOK))
	if err != nil {
		ctx.StatusCode(http.StatusInternalServerError)
	}
}
