# Purpose of hare project2

## Provide REST API for following actions:
1. List applications deployment status in specified Kubernetes namespace
2. Deploy applications into target Kubernetes namespace
3. Change applications configuration


## Hare image processing 
1. Generate image
    ```bash
    sudo docker build --no-cache -t hare .
    ```
2. Remove intermediate image
    ```bash
    docker rmi $(docker images -f "dangling=true" -q)
    ```
3. Deploy hare in local environment
   ```bash
   helm upgrade hare ./hare --debug --install --namespace=develop -f ./hare/values-local.yaml --dry-run 

   helm upgrade hare ./hare --debug --install --namespace=ops -f ./hare/values.yaml --dry-run
   ```
4. Check HTTP/2 support
   ```bash
   curl --http2 https://surpass-dev.bizconf.cn/hare/healthz --verbose
   ```
5. Enter hare pods
    ```bash
    kubectl exec -n ingress-nginx pods/hare-hare-76f96444b5-hrr9b -it -- sh

    curl --http2 http://10.120.102.102:9090/hare/healthz --verbose
    ```
6. Folder for related helm chart: /root/devops


## 相关配置
1. 每个节点上都要有: ~/.kube/config文件，用于Kubernetes in-cluster登录。
