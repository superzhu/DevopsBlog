package log

import (
	"github.com/kataras/golog"
	"github.com/kataras/iris/v12"
	"hare/configs"
)

var Logger *golog.Logger

func ConfigureLog(app *iris.Application) {
	Logger = app.Logger()
	Logger.SetLevel(configs.Configuration.Log.Level)
	Logger.SetTimeFormat(configs.Configuration.Log.TimestampFormat)
	Logger.Infof("Application Log Level: %s", configs.Configuration.Log.Level)
}
