package kubernetes

import (
	"errors"
	"hare/log"
	"k8s.io/client-go/kubernetes"
	"k8s.io/client-go/rest"
	"k8s.io/client-go/tools/clientcmd"
	"os"
	"path/filepath"
	"sync"
)

var apiCreationMutex sync.Mutex
var api *KubernetesAPI

type KubernetesAPI struct {
	ClientSet *kubernetes.Clientset
	Config    *rest.Config
}

//NoKubernetesConfigFile is the error returned by GetKubernetesAPI when no
// Kubernetes Config file was found or the file does not exist
var NoKubernetesConfigFile = errors.New("NoKubernetesConfigFile")

func resolveKubernetesConfig() (*rest.Config, error) {
	var conf *rest.Config

	log.Logger.Infof("Create the in-cluster Kubernetes config")
	var inClusterConfigError error
	conf, inClusterConfigError = rest.InClusterConfig()
	if inClusterConfigError != nil {
		log.Logger.Warnf("Cannot create the in-cluster Kubernetes config, error: %v", inClusterConfigError)
		log.Logger.Infof("Fallback to kubeconfig, Create the out-of-cluster Kubernetes config")

		kubeConfigFile := os.Getenv("KUBECONFIG")
		if kubeConfigFile == "" {
			homedir, err := os.UserHomeDir()
			if err != nil {
				return nil, err
			}
			kubeConfigFile = filepath.Join(homedir, ".kube", "config")
			_, err = os.Stat(kubeConfigFile)
			if err != nil {
				return nil, NoKubernetesConfigFile
			}
		}

		var outOfClusterConfigError error
		conf, outOfClusterConfigError = clientcmd.BuildConfigFromFlags("", kubeConfigFile)

		if outOfClusterConfigError != nil {
			return nil, outOfClusterConfigError
		}
	}

	conf.ContentType = "application/yaml"
	return conf, nil
}

func GetKubernetesAPI() (*KubernetesAPI, error) {
	if api != nil {
		return api, nil
	} else {
		apiCreationMutex.Lock()
		defer apiCreationMutex.Unlock()

		newApi := new(KubernetesAPI)
		if conf, err := resolveKubernetesConfig(); err != nil {
			return nil, err
		} else {
			newApi.Config = conf
		}

		if clientset, err := kubernetes.NewForConfig(newApi.Config); err != nil {
			return nil, err
		} else {
			newApi.ClientSet = clientset
		}

		api = newApi
	}

	return api, nil
}
