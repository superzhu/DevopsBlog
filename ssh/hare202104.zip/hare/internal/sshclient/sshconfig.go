package sshclient

import (
	"bytes"
	"golang.org/x/crypto/ssh"
	"io/ioutil"
	"time"
)

//https://github.com/EugenMayer/go-sshclient/blob/master/sshwrapper/config.go

type SshApi struct {
	SshConfig *ssh.ClientConfig
	Client    *ssh.Client
	Session   *ssh.Session
	User      string
	Key       string
	Host      string
	Port      int
	Timeout   time.Duration
	StdOut    bytes.Buffer
	StdErr    bytes.Buffer
}

func NewSshApi(host string, port int, user string, key string, timeout time.Duration) (sshApi *SshApi) {
	sshApi = &SshApi{
		User:    user,
		Key:     key,
		Host:    host,
		Port:    port,
		Timeout: timeout,
	}
	return sshApi
}

func DefaultSshApiSetup(host string, port int, user string, key string) (sshApi *SshApi, err error) {
	timeout := 20 * time.Second
	sshApi = NewSshApi(host, port, user, key, timeout)

	err = sshApi.defaultSshPrivkeySetup()
	return sshApi, err
}

func SshApiSetupWithTimeout(host string, port int, user string, key string, timeout time.Duration) (sshApi *SshApi, err error) {
	sshApi = NewSshApi(host, port, user, key, timeout)

	err = sshApi.defaultSshPrivkeySetup()
	return sshApi, err
}

func (sshApi *SshApi) defaultSshPrivkeySetup() error {
	privateKey, err := LoadPrivateKeyFile(sshApi.Key)
	if err != nil {
		return err
	}

	timeout := sshApi.Timeout
	if timeout == 0 {
		timeout = 5 * time.Second
	}
	sshApi.SshConfig = &ssh.ClientConfig{
		User:            sshApi.User,
		Auth:            []ssh.AuthMethod{privateKey},
		Timeout:         sshApi.Timeout,
		HostKeyCallback: ssh.InsecureIgnoreHostKey(),
	}

	return nil
}

func LoadPrivateKeyFile(file string) (ssh.AuthMethod, error) {
	buffer, err := ioutil.ReadFile(file)
	if err != nil {
		return nil, err
	}

	key, err := ssh.ParsePrivateKey(buffer)
	if err != nil {
		return nil, err
	}
	return ssh.PublicKeys(key), nil
}
