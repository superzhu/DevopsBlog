package sshclient

import (
	"github.com/pkg/sftp"
	"golang.org/x/crypto/ssh"
	"time"
)

type SftpApi struct {
	Host       string //ip
	Port       int    // 端口
	User       string //用户名
	Key        string //file path of private key
	SshConfig  *ssh.ClientConfig
	sshClient  *ssh.Client  //ssh client
	sftpClient *sftp.Client //sftp client
	Timeout    time.Duration
	LastResult string //最近一次运行的结果
}

func NewSftpApi(host string, port int, user string, key string, timeout time.Duration) (sftpApi *SftpApi) {
	sftpApi = &SftpApi{
		User:    user,
		Key:     key,
		Host:    host,
		Port:    port,
		Timeout: timeout,
	}
	return sftpApi
}

func DefaultSftpApiSetup(host string, port int, user string, key string) (sftpApi *SftpApi, err error) {
	timeout := 20 * time.Second
	sftpApi = NewSftpApi(host, port, user, key, timeout)

	err = sftpApi.defaultSftpPrivkeySetup()
	return sftpApi, err
}

func SftpApiSetupWithTimeout(host string, port int, user string, key string, timeout time.Duration) (sftpApi *SftpApi, err error) {
	sftpApi = NewSftpApi(host, port, user, key, timeout)

	err = sftpApi.defaultSftpPrivkeySetup()
	return sftpApi, err
}

func (sftpApi *SftpApi) defaultSftpPrivkeySetup() error {
	privateKey, err := LoadPrivateKeyFile(sftpApi.Key)
	if err != nil {
		return err
	}

	timeout := sftpApi.Timeout
	if timeout == 0 {
		timeout = 5 * time.Second
	}
	sftpApi.SshConfig = &ssh.ClientConfig{
		User:            sftpApi.User,
		Auth:            []ssh.AuthMethod{privateKey},
		Timeout:         sftpApi.Timeout,
		HostKeyCallback: ssh.InsecureIgnoreHostKey(),
	}

	return nil
}

func (sftpApi *SftpApi) Close() {
	if sftpApi.sshClient != nil {
		sftpApi.sshClient.Close()
	}

	if sftpApi.sftpClient != nil {
		sftpApi.sftpClient.Close()
	}
}
