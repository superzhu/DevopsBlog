package com;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import org.slf4j.Logger;

@Component
public class MyBean {
    private static final Logger logger = org.slf4j.LoggerFactory.getLogger(MyBean.class);

    @Autowired
    private Environment env;

    @Autowired
    private MyConfig config;

    @Autowired
    private SecretRead secretRead;

    @Scheduled(fixedDelay = 10000)
    public void hello() {
        logger.info("The message is: {},JAVA_HOME environment variable: {}",config.getMessage(),env.getProperty("JAVA_HOME"));
        logger.info("Secret username: {},secret password: {}",secretRead.getUsername(),secretRead.getPassword());
    }


}