package com;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.HashMap;
import java.util.Map;

@RestController
public class ConfigController {
    @Autowired
    private MyConfig config;

    @GetMapping("/configmap")
    public Map<String,Object> getConfig() {
        Map<String,Object> map = new HashMap<>();
        map.put("StringValue:",config.getMessage());
        return map;
    }
}
