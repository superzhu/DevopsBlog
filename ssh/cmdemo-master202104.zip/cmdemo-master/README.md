# Goals of project cmdemo --test9
1. Research how to externalize spring boot configuration
2. How to hot reload externalized configuration

## [Spring boot externalized configuration](https://blog.indrek.io/articles/externalized-configuration-in-spring-boot/)
<p>Properties files that are placed outside of your packaged jar override 
the ones inside your jar. Profile-specific files always take precedence. 
Properties are considered in the following order:</p>

1. Profile-specific application properties outside of your packaged jar
2. Profile-specific application properties packaged inside your jar
3. pplication properties outside of your packaged jar
4. Application properties packaged inside your jar

## Hot Reload using externalized Kubernetes ConfigMap
1. Without the need of configuration hot reload, spring-cloud-kubernetes is not needed.
2. ConfigMap 作为 volume 确实是会自动更新的，但是它的更新存在延时，最多的可能延迟时间是:
    - **Pod 同步间隔(默认10秒) + ConfigMap 本地缓存的 TTL**
    - kubelet 上 ConfigMap 的获取是否带缓存由配置中的 ConfigMapAndSecretChangeDetectionStrategy 决定
    - 注意，假如使用了 subPath 将 ConfigMap 中的某个文件单独挂载到其它目录下，那这个文件是无法热更新的（这是 ConfigMap 的挂载逻辑决定的）
3. SpringCloud Kubernetes Config 组件主要提供以下几种功能：
    - 实时监控 ConfigMap、Secret 配置变化从而更新服务配置。
    - 定时轮询加载 ConfigMap、Secret 配置从而更新服务配置。
4. 程序的重启依赖于spring-boot-actuator
    - org.springframework.cloud.context.restart.RestartEndpoint





## References
- [K8s 集群使用 ConfigMap 优雅加载 Spring Boot 配置文件](https://blog.csdn.net/aixiaoyang168/article/details/90116097)
- [Configuring Nodes to Authenticate to a Private Registry](https://kubernetes.io/docs/concepts/containers/images/)
- [Pull an Image from a Private Registry](https://kubernetes.io/docs/tasks/configure-pod-container/pull-image-private-registry/)
- [Kubernetes从Private Registry中拉取容器镜像的方法](https://blog.csdn.net/stonexmx/article/details/72673392)
- [Kubernetes Pod 中的 ConfigMap 配置更新](https://aleiwu.com/post/configmap-hotreload/)


    
    
